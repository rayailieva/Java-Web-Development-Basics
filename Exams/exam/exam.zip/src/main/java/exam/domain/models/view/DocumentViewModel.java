package exam.domain.models.view;

public class DocumentViewModel {

    private String id;
    private String title;

    public DocumentViewModel(){}

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
